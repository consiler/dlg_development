<iframe src="http://omninoggin.com/res/sidebar.php?name=<?php echo $this->name_dashed ?>" border=0 width=250 height=950></iframe>
